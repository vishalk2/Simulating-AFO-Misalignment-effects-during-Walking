1. Preferred Walking
--------------------
-> Follow below ranges for better results
-> Criterion Used: 5 Gait Cycles

Subject		Trial		Cell-AX		Cell-BA
-------		-----		-------		-------
 AB01		  1		1809		2432
 AB01		  2		954		1578
 AB02		  1		881		1489
 AB02		  2		1073		1694
 AB03		  1		671		989
 AB03		  2		552		871
 AB04		  1		1028		1604
 AB04		  2		1028		1604
 AB05		  1		866		1461
 AB05		  2		1029		1619

2. Stepping Up
--------------
-> Follow the default range for better results

3. Stepping Down
----------------
-> Follow the default range for better results