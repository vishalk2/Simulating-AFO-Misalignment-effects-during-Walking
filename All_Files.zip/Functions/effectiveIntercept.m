function intercept = effectiveIntercept(P1,S)
    % Intercept of line between two points
    intercept = P1(2)-S*P1(1);
end