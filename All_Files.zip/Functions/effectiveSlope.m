function slope = effectiveSlope(P1,P2)
    % Slope of line between two points
    slope = (P2(2)-P1(2))/(P2(1)-P1(1));
end